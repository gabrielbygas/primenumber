# primenumber
Assignment 4 
GABRIEL KALALA 21811863
